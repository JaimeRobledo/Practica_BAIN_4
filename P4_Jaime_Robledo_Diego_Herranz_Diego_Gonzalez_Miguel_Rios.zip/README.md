Integrantes: Diego Herranz, Miguel Rios, Diego Gonzalez y Jaime Robledo

# Librerías necesarias
pip install openai transformers datasets matplotlib

# Dependencias
Es necesario iniciar sesión en Hugging Face y solicitar acceso para el modelo google/gemma-3-1b-it